<table cellpadding="0" cellspacing="0" width="100%" >
                <tr>
                    <td style=" border: solid 1px #C3C9C9; padding:10px; border-right:none;font-size:13px;color:#333;width:275px">
                        <h4> Dutta  Fashion S.r.l</h4>
            <h6>  Sede Operativa </h6>	
            <h6>  Via Adda, 13/B</h6>
            <h6>  20863 Concorezzo (MB)</h6>		
            <h6>  Cell: 327.57.66.420</h6>	
            <h6>  info@duttafashion.it</h6>			
            <h6>  www.duttafashion.it</h6>	
            <h6>  P. I.V.A. e C.F. IT 08544880969</h6>	<br>
            
                    </td>
                    <td style=" border: solid 1px #C3C9C9; padding:10px; border-right:none; font-size:13px;color:#333;width:390px">
			<h6> Luogo di Destinzione :<?= !empty($form['invoice_number']) ? $form['invoice_number'] : '' ?></h6>	
                        <h6> D.D.T. Nr :<?= !empty($form['del_of']) ? $form['del_of'] : '' ?></h6>	
			<h6> Del :  </h6>	
                        <h6> Spett.le : </h6>	
                        <h6> P. I.V.A. e C.F : </h6>	
                    </td>
                </tr>
            </table>