<?php $this->load->view('_blocks/header') ?>




<div class="company_name company_name_1 company_name_2">

</div>


<?php $this->load->view('_blocks/footer') ?>