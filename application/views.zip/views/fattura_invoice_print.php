 <table cellpadding="0" cellspacing="0" width="100%">
        <tr>
          <td valign="top" style=" border: solid 1px #C3C9C9; padding:6px; border-right:none; font-size:15px;">
             <h4> Dutta  Fashion S.r.l</h4>
            <h6>  Sede Operativa </h6>	
            <h6>  Via Adda, 13/B</h6>
            <h6>  20863 Concorezzo (MB)</h6>		
            <h6>  Cell: 327.57.66.420</h6>	
            <h6>  info@duttafashion.it</h6>			
            <h6>  www.duttafashion.it</h6>	
            <h6>  P. I.V.A. e C.F. IT 08544880969</h6>		
            <h6>  Nr. REA MI - 2032599)</h6>
            <h5>  Sede Legale</h5>	
            <h6>  Viale E. Caldara, 24 - 20122 Milano</h6>
            <h6>  P. I.V.A. e C.F.  IT 08544880969</h6>
            <h6>  VAT Nr. and Tax Code  IT 08544880969</h6>	
            <h6>  REA - Chamber of Commerce Company Nr.  MI - 203259</h6>	
            <h6>  Cap. Soc. I.V. - Capital - Euro 10.000,00</h6>
            <h6>  Banca - Bank: Banco Popolare - Ag.151 - Concorezzo (MB)</h6>	
            <h6>  Iban - IT71G0503432980000000003162</h6>	
            <h6>  Pagamento / Term of Payment	</h6>	

            </td>
          <td valign="top" style=" border: solid 1px #C3C9C9; padding:6px; border-right:none; font-size:15px;">
          <h5>   FATTURA - INVOICE</h5>
          <h6>   Fattura Nr. / Invoice Nr. : <?= !empty($form['invoice_number']) ? $form['invoice_number'] : '' ?></h6>
          <h6>  Del / Of :<?= !empty($form['del_of']) ? $form['del_of'] : '' ?></h6>
          <h6>   Cliente/Customer : <?= !empty($form['customer_name']) ? $form['customer_name'] : '' ?> </h6>
          <h6>   Partita IVA /VAT Nr.  :<?= !empty($form['vat_nr']) ? $form['vat_nr'] : '' ?> </h6>
          <h6>    Codice Fiscale/Tax Code : <?= !empty($form['vat_tax_code']) ? $form['vat_tax_code'] : '' ?></h6>
          <h6>     Rif. D.D.T. Nr.  Ref. Pro-Forma Invoice Nr:<?= !empty($form['ref_ddt_document_nr']) ? $form['ref_ddt_document_nr'] : '' ?></h6>
          </td>
        </tr>
      </table>
	 
 
      <table cellpadding="5" cellspacing="0" width="100%" style="margin-top:-15px;">
        <tr  >
            <th  width="90" align="center"style="margin-top:-15px; border: solid 1px #C3C9C9;font-size:13px;color:#000000;">Articolo Item </th>          	
			<th  width="200" align="center"style="margin-top:-15px; background:#078DB9;border: solid 1px #C3C9C9;font-size:13px;color:#000000;"> Descrizione dei Beni Item Description</th>
			<th  width="90" align="center"style="margin-top:-15px; border: solid 1px #C3C9C9;font-size:13px;color:#000000;">Q.tà/Nr. Q.ty/Nr.</th>
            <th  width="90" align="center"style="margin-top:-15px; border: solid 1px #C3C9C9;font-size:13px;color:#000000;">Prezzo Unitario € Unit Price €</th>
            <th  width="70" align="center"style="margin-top:-15px; border: solid 1px #C3C9C9;font-size:13px;color:#000000;">I.V.A. VAT</th>
            <th  width="90" align="center"style="margin-top:-15px; border: solid 1px #C3C9C9;font-size:13px;color:#000000;">Sconto   Discount</th>
            <th  width="90" align="center"style="margin-top:-15px; border: solid 1px #C3C9C9;font-size:13px;color:#000000;">Importo € Amount €</th>
        </tr>
        
		
            	 <?php $key = 0;

        foreach ($form['item'] as $key => $item):
            ?>
				
				<tr align="center" style="background:#00D9D9;">
           
                <td width="90" align="center"style="margin-top:-15px;font-size:13px;border: solid 1px #C3C9C9;background:#00D9D9;color:#FDFDFF;"><?= !empty($item['description']) ? $item['description'] : '' ?> </td>
                <td width="200" align="center"style="margin-top:-15px; font-size:13px;border: solid 1px #C3C9C9;color:#FDFDFF;"><?= !empty($item['article']) ? $item['article'] : '' ?> </td>
                <td width="90" align="center"style="margin-top:-15px; font-size:13px;border: solid 1px #C3C9C9;color:#FDFDFF;"><?= !empty($item['qty']) ? $item['qty'] : '' ?> </td>
                <td width="90" align="center"style="margin-top:-15px;font-size:13px; border: solid 1px #C3C9C9;color:#FDFDFF;"><?= !empty($item['unit_price']) ? $item['unit_price'] : '' ?> </td>
                <td width="70" align="center"style="margin-top:-15px; font-size:13px;border: solid 1px #C3C9C9;color:#FDFDFF;"><?= !empty($item['vat']) ? $item['vat'] : '' ?> </td>
                <td width="90" align="center"style="margin-top:-15px;font-size:13px; border: solid 1px #C3C9C9;color:#FDFDFF;"><?= !empty($item['discount']) ? $item['discount'] : '' ?> </td>
                <td width="90" align="center"style="margin-top:-15px;font-size:13px; border: solid 1px #C3C9C9;color:#FDFDFF;"><?= !empty($item['amount']) ? $item['amount'] : '' ?> </td>
            </tr>



        <?php endforeach; ?>

        	
        	
        
      <tr align="left" style="background:#E0E6E6;">
          <td  width="200" align="center"style="margin-top:-15px;font-size:13px; #C3C9C9;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;#C3C9C9;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px; #C3C9C9;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px; #C3C9C9;color:#333;"></td>
     
            <td  style="font-size:13px; border: solid 1px #C3C9C9;color:#000000;width:200px;">Spese Accessorie € Charges €    </td>
            <td  style="font-size:13px;width:50px;border:solid 1px #C3C9C9;color:#333;"><?= !empty($form['accessories_cost']) ? $form['accessories_cost'] : '' ?></td>
        </tr>
        
        <tr align="left">
          <td  width="200" align="center"style="margin-top:-15px;font-size:13px;  #C3C9C9;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px; #C3C9C9;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px; #C3C9C9;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;#C3C9C9;color:#333;"></td>
        
             <td  style="background:#078DB9;font-size:13px; border: solid 1px #C3C9C9;color:#000000;width:200px;">Spese di Trasporto € Transport Costs €</td>
          <td  style="font-size:13px;width:50px;border:solid 1px #C3C9C9;color:#333;"><?= !empty($form['transport_cost']) ? $form['transport_cost'] : '' ?></td>
        </tr>
        
        <tr align="left">
          <td  width="200" align="center"style="margin-top:-15px;font-size:13px; color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;color:#333;"></td>
        
             <td  style="background:#078DB9;font-size:13px; color:#000000;width:200px;">Imponibile €  Taxable Income €</td>
            <td  style="font-size:13px;width:50px;border:solid 1px #C3C9C9;color:#333;"> <?= !empty($form['income_tax']) ? $form['income_tax'] : '' ?></td>
        </tr>
        
        <tr align="left" style="background:#E0E6E6;">
          <td  width="200"></td>
          <td width="90" align="center"></td>
          <td width="90" align="center"></td>
          <td width="90" align="center"></td>
         
             <td  style="background:#078DB9;font-size:13px; border: solid 1px #C3C9C9;color:#000000;width:200px;">Imposta I.V.A. €VAT € 22%</td>
<td  style="font-size:13px;width:50px;border:solid 1px #C3C9C9;color:#333;"><?= !empty($form['tax']) ? $form['tax'] : '' ?></td>
        </tr>
        
        <tr align="left" style="background:#E0E6E6;">
           <td  width="200" align="center"style="margin-top:-15px;font-size:13px;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;color:#333;"></td>
          <td width="90" align="center"style="margin-top:-15px; font-size:13px;color:#333;"></td>
          <td  style="background:#078DB9;font-size:13px;color:#000000;width:200px;">Totale Fattura € Total Invoice €</td>
          <td  style="font-size:13px;width:50px;border:solid 1px #C3C9C9;color:#333;"><?= !empty($form['total_invoice']) ? $form['total_invoice'] : '' ?></td>
        </tr>
        
        
        
      </table>
      
      
   