<?php $this->load->view('_blocks/header') ?>
<?php $this->load->view('invoice_form') ?>
</div>
<?php $this->load->view('_blocks/footer') ?>