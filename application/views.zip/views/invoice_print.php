 
<!-- start contener-->
<div class="contener" style="box-shadow: 0 0 5px #ccc; width:980px; margin:auto;"> 

    <!-- start body contener-->

    <div class="body_contenet">

        <div class="company_name company_name_2" style="padding:20px; background:#FFF; font-size:13px;  color:#333; line-height:22px; width:980px; margin:auto;">
            <table cellpadding="0" cellspacing="0" width="100%">
                <tr>
                    <td style=" border: solid 1px #C3C9C9; padding:10px; border-right:none;" width="400">
                        <div style="border-bottom: solid 1px #C3C9C9;"><h1>Dutta  Fashion S.r.l</h1>
                            Sede Operativa 			
                            <p> Via Adda, 13/B</p>
                            <p>  20863 Concorezzo (MB)	</p>		
                            <p> Cell: 327.57.66.420	</p>		
                            <p>  info@duttafashion.it	</p>		
                            <p>  www.duttafashion.it			
                                P. I.V.A. e C.F. IT 08544880969	</p>		
                            "Nr. REA MI - 2032599)</div>
                        <div style="border-bottom: solid 1px #C3C9C9; padding:10px;"><strong>Luogo di Destinzione</strong> </div>	
                    </td>
                    <td valign="top" style=" border: solid 1px #C3C9C9; padding:10px;" align="left" width="400">
                        <div style="border-bottom: solid 1px #C3C9C9; padding:5px;"><strong>Luogo di Destinzione :</strong> We are excited about what lies ahead.</div>	
                        <div style="border-bottom: solid 1px #C3C9C9; padding:5px;"><strong>D.D.T. Nr :</strong> .</div>	
                        <div style="border-bottom: solid 1px #C3C9C9; padding:5px;"><strong>Del :</strong>  </div>	
                        <div style="border-bottom: solid 1px #C3C9C9; padding:5px;"><strong>Spett.le :</strong> </div>	
                        <div style="border-bottom: solid 1px #C3C9C9; padding:5px;"><strong>P. I.V.A. e C.F :</strong> </div>	
                    </td>
                </tr>
            </table>


        </div>


        <div class="company_name company_name_2" style="padding:20px;  background:#FFF;  font-size:13px;  color:#333;  line-height:22px; width:980px; margin:auto;">
            <table cellpadding="5" cellspacing="1" width="100%" style="margin-top:-15px; border: solid 1px #C3C9C9;">
                <tr style="background:#078DB9; color:#fff;">
                    <th>QuantitÃ /Nr.</th>
                    <th>Descrizione dei Beni</th>
                    <th>Articolo</th>
                    <th>Marchio</th>
                    <th>Composizione</th>
                    <th>Colore</th>
                    <th>Taglia</th>
                </tr>
              
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td>We are </td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 45455</td>
                    <td>We are excited</td>
                </tr>
                
                 
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td>excited</td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 45345</td>
                    <td>We are excited</td>
                </tr>
                
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td>We are </td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 5434534</td>
                    <td>We are excited</td>
                </tr>
                
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td>We</td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 3453453</td>
                    <td>We are excited</td>
                </tr>
                
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td>excited</td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 453453</td>
                    <td>We are excited</td>
                </tr>
                
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td> are </td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 4534535</td>
                    <td>We are excited</td>
                </tr>
                 
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td> excited</td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 45345534</td>
                    <td>We are excited</td>
                </tr>
                
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td>are</td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 53453</td>
                    <td>We are excited</td>
                </tr>
                
                <tr align="center" style="background:#E0E6E6;">
                    <td>We are excited</td>
                    <td> about what lies</td>
                    <td>excited</td>
                    <td> about what lies</td>
                    <td>We are excited</td>
                    <td> 453453</td>
                    <td>We are excited</td>
                </tr>
               

                <tr align="center" style="background:#E0E6E6;">
                    <td></td>
                    <td style="background:#078DB9; color:#fff;">QuantitÃ  Tot. Nr.</td>
                    <td style="background:#078DB9; color:#fff;">Tot. Colli Nr.</td>
                    <td></td>
                    <td style="background:#078DB9; color:#fff;">Porto</td>
                    <td></td>
                    <td></td>
                </tr>

                <tr align="left" style="background:#E0E6E6;">
                    <td style="background:#078DB9; color:#fff;">Aspetto Esteriore dei Beni</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td style="background:#078DB9; color:#fff;">Causale del Trasporto</td>
                    <td></td>
                    <td></td>
                </tr>

                <tr align="left" style="background:#E0E6E6;">
                    <td style="background:#078DB9; color:#fff;">Trasporto a Cura del</td>
                    <td></td>
                    <td></td>
                    <td style="background:#078DB9; color:#fff;">Vettore</td>
                    <td> </td>
                    <td></td>
                    <td></td>
                </tr>

                <tr align="left" style="background:#E0E6E6;">
                    <td style="background:#078DB9; color:#fff;">Data e Ora Inizio Trasporto</td>
                    <td></td>
                    <td></td>
                    <td style="background:#078DB9; color:#fff;">Firma del Vettore</td>
                    <td> </td>
                    <td></td>
                    <td></td>
                </tr>

                <tr align="left" style="background:#E0E6E6;">
                    <td style="background:#078DB9; color:#fff;">Data e Ora Fine Trasporto</td>
                    <td></td>
                    <td></td>
                    <td style="background:#078DB9; color:#fff;">Firma del Mittente</td>
                    <td> </td>
                    <td></td>
                    <td></td>
                </tr>

                <tr align="left" style="background:#E0E6E6;">
                    <td style="background:#078DB9; color:#fff;">Firma del Destinatario</td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td> </td>
                    <td></td>
                    <td></td>
                </tr>
                <tr align="left" style="background:#E0E6E6;">
                    <td style="background:#078DB9; color:#fff;">Annotazioni: </td>
                    <td></td>
                    <td></td>
                    <td></td>
                    <td> </td>
                    <td></td>
                    <td></td>
                </tr>
                <tr align="left" style="background:#E0E6E6;">
                    <td align="center" colspan="7">Dutta Fashion S.r.l.  - Sede Legale Viale E.  Caldara, 24 - 20122 Milano </td>
                </tr>

            </table>


        </div>

    </div>

    <!-- end body contener--> 

</div>

